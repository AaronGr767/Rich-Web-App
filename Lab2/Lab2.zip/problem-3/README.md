Problem 3:
Made a developer tool which functions to remove all content from Trinity University's website and displays an error message with a link that redirects the user to TUD's home page. 
